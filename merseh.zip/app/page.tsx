import Home from "@/Components/Home/Home";
import Layout from "@/Components/Layout/Layout";

export default function page() {
  return (
    <Layout>
      <Home />
    </Layout>
  );
}
