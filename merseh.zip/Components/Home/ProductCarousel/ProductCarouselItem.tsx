import React from "react";

import { motion } from "framer-motion";
import Image from "next/image";
import Link from "next/link";
import splitNumber from "@/Components/utils/splitNumber";
interface Props {
  id: number;
  name:string
  imageUrl: string;
  price:number
}

export default function ProductCarouselItem({ id, name, imageUrl, price }: Props) {
  return (

      <motion.div
        transition={{ duration: 0.3 }}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="flex justify-center  w-full h-full "
        onDrag={(e) => e.preventDefault()}
      >
        <Link
          // style={{ pointerEvents: "none" }}
          // aria-disabled={drag !== 0 ? "true" : "false"}
          href={`/product/${id}/${name.replaceAll(" ", "-")}`}
          className="flex flex-row     rounded-[12px]  "
        >
          <div className="pb-4  sm:px-5 h-full  justify-between  gap-3 flex flex-col  items-center sm:justify-center relative">
            <div className="w-full h-full flex flex-col items-center justify-center">
              {imageUrl ? (
                <Image
                  title={name.replaceAll(" ", "-")}
                  onSelectCapture={() => {
                    return false;
                  }}
                  onCopy={() => {
                    return false;
                  }}
                  className="sm:w-full w-auto h-full rounded-[12px] sm:h-auto basis-1/4"
                  style={{ objectFit: "contain" }}
                  src={imageUrl}
                  alt={imageUrl.split(".").at(0) || ""}
                  quality={100}
                  width={200}
                  placeholder="blur"
                  height={200}
                  blurDataURL="data:image/webp;base64,UklGRpQGAABXRUJQVlA4WAoAAAAgAAAAKAAAKAAASUNDUMgBAAAAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADZWUDhMpQQAAC8oAAoAr6agbRsp4c/oyH3ddhQEAkn7G01HkG2z+hOd7vOvyG3b5phZNs9YrwVYgEIoFPCNnqcIdlEKoBlqHtABC6AoQOxOaZ4oKKLC4skDIhFRUVUpBB1QwO4CErsTRRNHgRZQ8tfwvtDnutF46BbtorwoAIqo19idSF5Mp6EAUBAAgFHaZO/p9iRxkEupexNaB3FLM9zrEuo466R1XEIkwV5q3V7j1ZynJddQMdCS4KJ10zguFomLlHuQ4TjuCRH9Z+C2kSIfLO8ezN0jGIZhGIZhGMZBL5neUCQxQpCUzjA1v0p/tDMMwzAMwzAMwwdOkJo/DKb5VdrG3+I73atRHMcJjVZv+ntlgzf75rxxYnwEwzCcpCaN5uU1656Dn4M1s+H16HB/Xz9GaLSGmQXL1s7//OxaZvQavL8LRbsxgpp8a+ZftK2YJkaH0Geqp53dGMlOdvkl1sW/KLxL9RhBlOpuXKMzmlfWt/cdfEZumvVk/1NE0axoUar7CUo/NW/5sGPnM9IyrcV/RJq/g+E6BaIeJLV/zi6vWXcdPHquGDX9Hc2wHILksEKJvtBMmuYttM3ucN9zUU+gLTBUlJdXBMGKJ93E74aZpTXr7ie3/jNPDKsaHubJsrNleRDcosbGdG8P44dPsjZN9bZXFuVIk5Kk2XkP6pDnv1Ls5HB3M9JiJDsbIVmqOC5OnJRdVKlQDYzpWCF5GEBuRq4YXqrggjRxhEgUFpckK6tDnhNawyw74R65pMMQuUwSdiMwUBgqTsuTK9SYRs+a5MDBPfIfbZ+iIj0OFPj7C4RhEllZnbKbdIYFK+EMnDkKbSxKCQv08/DwFoBxafmVLSjO7myzO7h2ekajhu9IQMDjwoXLvoFhSXfYxRlncffzzjGXiVRVyuKE3hfOnDnvEfCFOBdqVPX/pjPNr6xbd+12LkZCKc+Ouu5x9sSJU5f8bsSll3I12Hbtdo7XZ3j5SJ4eHnD51LFjJy54h8SkFcFIN6E1mpf+pd3BESg9DLh08ujR42e9AqOkeTUISmgNM0sW+nPCYcVJGgpcOHH0iFOkNK+yBR2hXO1yBIT+RSskDQMunuA4uUw172z4yOmXNuh2GMCqPu8dHCUtqG53RVttO5wnBEoPF1w5zRomjEsvghFnYZrNxgVHHmREBXqeO3Xq7FUATMwqqUV+Jlje09ZtG1fQ4o/k2XFCn8tnz170Fohu5VTUKbsPhzkLFnrLus1JWSkTg4DHpUsefsERSd9AjR19o2wbtNXKhXhSdUciEvh4eHgHgLHS+3KFqp9kW3NHBeclhQUBfn5AoEicWVj5gxob1xnZtjisGkl1XZE0GrwGANfBqK9yy2rb0WGNqw9bHL8dI6luLE5PEAkDA4WiOOkdqP5xF/7qjQua0xjaVJ4tCQeFQjDyVnqevLGjm6D078xOGzTNwaT5SQHJkqJF4M3QuK9Zn3//6Gu9ybzEQ/f38jvJ8WGiL6PEqbIyuOXZEKk18EJ1t3x797Y4Kiw8VpJ2p6K2XY3x8um9ieppq8xLl8RFRcVJ0u9BdUgnNj7hYp3LmonqdxGdmJSZ97AOQYfHJwzTLmgA"
                />
              ) : null}
              <h3 className="font-[500] basis-2/4 text-[14px] sm:text-[14px] text-black1 w-fit">
                {name}
              </h3>
            </div>
            <div className="flex-row flex items-center gap-1">
              <span className="font-normal text-nowrap text-[14px] sm:text-[16px] basis-1/4 text-green1 w-fit ">
                {splitNumber(price)}{" "}
              </span>
              <span className="text-[11px] text-black1">تومان</span>
            </div>
          </div>
          <div className="md:border-l border-[#f3f3f3] w--[5px] h-full -order-last:border-l-8" />
        </Link>
      </motion.div>

  );
}
