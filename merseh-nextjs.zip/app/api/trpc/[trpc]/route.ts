import { createContext } from "@/server/context";
import { appRouter } from "@/server/routers/_app";

import { fetchRequestHandler } from "@trpc/server/adapters/fetch";

const handler = (req: Request) =>
  fetchRequestHandler({
    endpoint: "/api/trpc",
    req,
    router: appRouter,
    createContext: async () =>
      await createContext({ req, res: undefined as unknown as Response }),
  });

export { handler as GET, handler as POST };
